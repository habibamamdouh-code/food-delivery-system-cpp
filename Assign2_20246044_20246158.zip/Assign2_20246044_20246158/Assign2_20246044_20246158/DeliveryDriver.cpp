
#include "DeliveryDriver.h"
#include <iostream>
using namespace std;

//default constructor
DeliveryDriver ::DeliveryDriver ():User()
{
    VehicleType= "";
    completedDeliveries =0;
    totalEarnings =0.0;
    cout<<"default Delivery Driver crated"<<endl;
    DriversCount++;
}

//parameterized constrctor
DeliveryDriver ::DeliveryDriver (string id,string n,string num,string type,int deliver,double total):User(id,n,num)
{
    VehicleType=type ;
    completedDeliveries =deliver;
    totalEarnings =total;
    DriversCount++;
}

//override function
void DeliveryDriver ::displayInfo() 
{
    cout<<"type :"<<VehicleType<<endl;
    cout<<"deliver :"<<completedDeliveries<<endl;
    cout<<"total earnings :" <<totalEarnings<<endl;
}

double DeliveryDriver::calculateEarnings()
{
    return totalEarnings ;
}

void DeliveryDriver::completeDelivery(double orderValue)
{
    if (orderValue > 0)
    {
        totalEarnings += orderValue * 0.15;
        completedDeliveries++;
    }
    else
    cout<<"invalid value"<<endl;
}

// Prefix 
DeliveryDriver& DeliveryDriver::operator++()
{
    ++ completedDeliveries;
    return *this;
    
}

//Postfix
DeliveryDriver DeliveryDriver::operator++(int)
{
    DeliveryDriver temp = *this;
    completedDeliveries++;
    return temp;
}
//Getters
string DeliveryDriver::getVehicleType() const
{
    return VehicleType;
}
int DeliveryDriver::getcompletedDeliveries() const
{
    return completedDeliveries;
}
double DeliveryDriver::gettotalEarnings() const
{
    return  totalEarnings;
}
int DeliveryDriver::getDriversCount()
{
    return DriversCount;
}


// Destructor
DeliveryDriver::~DeliveryDriver()
{
    DriversCount--;
}




