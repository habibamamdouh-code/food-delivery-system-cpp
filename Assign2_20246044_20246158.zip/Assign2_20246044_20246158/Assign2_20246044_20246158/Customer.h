
// GROUP 9
// Habiba  20246044 
// Maria   20246158

#pragma once
#include <iostream>
#include "User.h"
using namespace std;
class Customer : public User
{
private:
    string deliveryAddress;
    int loyaltyPoints;
    static int customerCount;
public:
    //Constructors
    Customer();
    Customer(string id, string n, string num, string address, int point);

    // override functions
    void displayInfo() override;
    double calculateEarnings() override;

    // Setters
    void setdeliveryAddress(string address);
    void setloyaltyPoints(int point);

    //Getters
    string getdeliveryAddress() const;
    int getloyaltyPoints() const;
    static int getCustomerCount();
    //Operator+=
    Customer& operator +=(int point);

    // Destructor
    ~Customer();
};



















