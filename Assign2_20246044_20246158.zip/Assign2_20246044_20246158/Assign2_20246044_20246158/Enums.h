
// GROUP 9
// Habiba  20246044 
// Maria   20246158

enum OrderStatus
{
	PENDING , PREPARING , OUT_FOR_DELIVERY , DELIVERED , CANCELED
};

enum UserType
{
	CUSTOMER , DRIVER
};