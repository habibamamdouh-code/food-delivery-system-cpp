
// GROUP 9
// Habiba  20246044 
// Maria   20246158

#include "FoodItem.h"
#include <iostream>
using namespace std;

// Constructors
FoodItem::FoodItem()
{
	itemName = "";
	price = 0.0;
	quantity = 0;
}

FoodItem::FoodItem(string na, double p, int q)
{
	itemName = na;
	price = p;
	quantity = q;
}

// Setters
void FoodItem::setItemName(string na)
{
	itemName = na;
}

void FoodItem::setPrice(double p)
{
	price = p;
}

void FoodItem::setQuantity(int q)
{
	quantity = q;
}

// Getters
string FoodItem::getName()
{
	return itemName;
}

double FoodItem::getPrice()
{
	return price;
}

int FoodItem::getQuantity() 
{
	return quantity;
}

// Methods
double FoodItem::calculateItemTotal()
{
	double itemTotal;
	itemTotal = price * quantity;
	return itemTotal;
}

void FoodItem::displayItem()
{
	cout << itemName << " * " << quantity << " @ " << price << " = " << calculateItemTotal();
}




