
// Group 9
// Habiba  20246044 
// Maria   20246158

#pragma once
#include <iostream>
using namespace std;

class FoodItem
{
private:
	string itemName;
	double price;
	int quantity;

public:
	// Constructors
	FoodItem();
	FoodItem(string na, double p, int q);

	// Setters
	void setItemName(string na);
	void setPrice(double p);
	void setQuantity(int q);

	// Getters
	string getName();
	double getPrice();
	int getQuantity();

	// Methods
	double calculateItemTotal();
	void displayItem();
};