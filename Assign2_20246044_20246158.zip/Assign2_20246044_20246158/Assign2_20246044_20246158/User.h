
// GROUP 9
// Habiba  20246044 
// Maria   20246158

#pragma once
#include <iostream>
using namespace std;

class User
{
   protected:
       string userId;
       string name;
       string phoneNumber;
       static int totalUsers;

   public:
       // Constructors
       User();
       User(string id, string n, string num);

       // Pure virtual functions
       virtual void displayInfo() = 0;
       virtual double calculateEarnings() =0;
       //Static function
       static int getTotalUsers();

       // Setters
       void setId(string id);
       void setName(string n);
       void setPhoneNum(string num);

       // Getters
       string getId();
       string getName();
       string getPhoneNum();

       // Virtual Destructor
       virtual ~User();

};

