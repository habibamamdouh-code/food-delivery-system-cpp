// GROUP 9
// Habiba  20246044 
// Maria   20246158

#include "User.h"
#include <iostream>
using namespace std;

// initialize the static variable
int User::totalUsers = 0;     

// default constructor 
User::User()             
{
    totalUsers++;
    userId = "";
    name = "";
    phoneNumber = "";
}

// Parameterized constructor
User::User(string id, string n, string num)  
{
    totalUsers++;
    userId = id;
    name = n;
    phoneNumber = num;
}


// Static function
int User::getTotalUsers()
{
    return totalUsers;
}

// Setters
void User::setId(string id)
{
    userId = id;
}

void User::setName(string n)
{
    name = n;
}

void User::setPhoneNum(string num)
{
    phoneNumber = num;
}

// Getters
string User::getId()
{
    return userId;
}

string User::getName()
{
    return name;
}

string User::getPhoneNum()
{
    return phoneNumber;
}

User::~User()
{
    totalUsers--;
}


