
// GROUP 9
// Habiba  20246044 
// Maria   20246158

#pragma once
#include <iostream>
#include "Customer.h"
#include "DeliveryDriver.h"
#include "FoodItem.h"
#include "Enums.h"


using namespace std; 

class Order
{
private:
	string orderId;
	Customer* customer;   // pointer (aggregation)
	DeliveryDriver* driver;   // pointer (composition)
	FoodItem* items;       // dynamic array (composition)
	int itemCount;
	int capacity;
	OrderStatus status;
	static int totalOrders;

public:
	// Constructors
	Order();                                // default
	Order(string order_id, Customer* p);   // parameterized
	Order(const Order& obj);              // Copy

	// Destructor
	~Order();

	// Methods
	void addItem(const FoodItem& item);
	void assignDriver(DeliveryDriver* drv);
	void updateStatus(OrderStatus newStatus);
	double calculateTotal();
	void displayOrder();
	static int getTotalOrders();

	//Getters
	string getOrderId();
	void getCustomer();
	void getDriver();
	OrderStatus getStatus();
	int getItemCount();

	// Overloading
	Order& operator+=(const FoodItem& item);
	Order operator+(const Order& order2) const;
	friend void operator<<(const Order& order ,std::ostream& os);
	friend void operator>(const Order& order1, const Order& order2);
	FoodItem& operator[](int index);
	const FoodItem& operator[](int index) const;
};
