
// GROUP 9
// Habiba  20246044 
// Maria   20246158

#include "Order.h"
#include <iostream>
using namespace std;

// Default Constructor
Order::Order()
{
	totalOrders++;
}

// Parameterized Constructor
Order::Order(string order_id, Customer* p)
{
	orderId = order_id;
	customer = p;
}

// Copy Constructor
Order::Order(const Order& obj)              
{
	// Copiny primitive variables
	orderId = obj.orderId;
	itemCount = obj.itemCount;
	capacity = obj.capacity;
	status = obj.status;
	customer = obj.customer;
	driver = obj.driver;

	//Deep Copy
	items = new FoodItem[obj.capacity];
	for (int i = 0; i < obj.itemCount; i++)
	{
		items[i] = obj.items[i];
	}

}

// Destructor
Order::~Order()
{
	totalOrders--;
	delete[] items;
}

// Methods
void Order::addItem(const FoodItem& item)
{
	itemCount++;
	items[itemCount] = item;
}

void Order::assignDriver(DeliveryDriver* drv)
{
	driver = drv;
	cout << "The delivery driver is " << driver;
}

void Order::updateStatus(OrderStatus newStatus)
{
	status = newStatus;
	if (status == DELIVERED)
	{
		driver->completeDelivery(items[itemCount].getPrice());
		driver++;
		customer->getloyaltyPoints();  
	}
}

 double Order::calculateTotal()
{
	 double totalPrice = 0;
	 for (int i = 0; i < itemCount; i++)
	 { 
		 totalPrice += items[i].calculateItemTotal();
	 }
	 return totalPrice;
}

 void Order::displayOrder()
 {
	 cout << "orderId : " << getOrderId()<<endl;
	 cout << "Customer information :" << endl;
	 getCustomer();
	 for (int i = 0; i < itemCount; i++)
	 {
		 items[i].displayItem();
	 }
	 cout << "Order Status : " << getStatus();
	 cout << " Item count : " << getItemCount();

 }

 int Order::getTotalOrders()
 {
	 return totalOrders;
 }

 string Order::getOrderId()
 {
	 return orderId;
 }

 void Order::getCustomer()
 {
	 customer->displayInfo();
 }

 void Order::getDriver()
 {
	 driver->displayInfo();
 }

 OrderStatus Order::getStatus()
 {
	 return status;
 }

 int Order::getItemCount()
 {
	 return itemCount;
 }

 Order& Order::operator+=(const FoodItem& item )
 {
	addItem(item);
	return*this;
 }

 Order Order::operator+(const Order& order2) const 
 {
	 Order newOrder(orderId + "_" + order2.orderId, customer);
	 for (int i = 0; i < itemCount; i++) {
		 newOrder.addItem(items[i]);
	 }
	 for (int i = 0; i < order2.itemCount; i++) {
		 newOrder.addItem(order2.items[i]);
	 }
	 return newOrder;
 }

 void operator<<( Order& order, std::ostream& out)
 {
	 order.displayOrder();
 }

 bool operator>(Order& order1,Order& order2)
 {
	 if (order1.calculateTotal() > order2.calculateTotal())
		 return true;
	 else
		 return false;
 }

 FoodItem& Order::operator[](int index)
 {
	 return items[index];
 }

 const FoodItem& Order::operator[](int index) const
 {
	 return items[index];
 }

 