
// GROUP 9
// Habiba  20246044
// Maria   20246158

#include <iostream>
#include <fstream>
#include <vector>
#include <string>

#include "User.h"
#include "Customer.h"
#include "DeliveryDriver.h"
#include "FoodItem.h"
#include "Order.h"
#include "Enums.h"

using namespace std;

struct OrderRecord {
    int orderId;
    int customerId;
    int driverId;
    double total;
    int status;        // 0=Pending, 1=Assigned, 2=Delivered
};


bool loadOrderByPosition(const string& filename, int position)
{
    ifstream fin(filename, ios::binary);
    if (!fin) {
        cerr << "Error opening binary file.\n";
        return false;
    }

    OrderRecord rec;
    int offset = position * static_cast<int>(sizeof(OrderRecord));

    fin.seekg(offset, ios::beg);
    if (!fin.read(reinterpret_cast<char*>(&rec), sizeof(OrderRecord))) {
        cout << "Invalid position.\n";
        return false;
    }

    // Display loaded record
    cout << "\n=== Loaded Order From Binary ===\n";
    cout << "Order ID: " << rec.orderId << "\n";
    cout << "Customer ID: " << rec.customerId << "\n";
    cout << "Driver ID: " << rec.driverId << "\n";
    cout << "Total: " << rec.total << " EGP\n";
    cout << "Status: " << rec.status << "\n";
    cout << "================================\n";

    return true;
}

void binaryFileStats(const string& filename)
{
    ifstream fin(filename, ios::binary | ios::ate);
    if (!fin) {
        cerr << "Error opening binary file.\n";
        return;
    }

    int fileSize = static_cast<int>(fin.tellg());
    int recordSize = static_cast<int>(sizeof(OrderRecord));
    int count = recordSize ? fileSize / recordSize : 0;

    cout << "\n===== Binary File Statistics =====\n";
    cout << "File Size: " << fileSize << " bytes\n";
    cout << "Record Size: " << recordSize << " bytes\n";
    cout << "Number of Orders: " << count << "\n";
    cout << "==================================\n";
}

void saveCompletedOrders(const vector<Order*>& orders, const string& filename)
{
    ofstream fout(filename);
    if (!fout)
    {
        cerr << "Error opening file for completed orders.\n";
        return;
    }

    for (auto ord : orders)
    {
        if (!ord) continue;
        if (ord->getStatus() == OrderStatus::DELIVERED)
        {
             ord->displayOrder() ;
        }
    }

    fout.close();
}

void saveDriverStats(const vector<DeliveryDriver*>& drivers, const string& filename)
{
    ofstream fout(filename);
    if (!fout)
    {
        cout << "Error opening driver stats file.\n";
        return;
    }

    for (auto d : drivers)
    {
        if (!d) continue;
        fout << "Driver ID: " << d->getId()
            << " | Name: " << d->getName()
            << " | Completed Deliveries: " << d->getcompletedDeliveries()
            << " | Earnings: " << d->gettotalEarnings() << " EGP"
            << "\n";
    }

    fout.close();
}

int main()
{
    cout << "=======================================================================\n";

    int num = 0;

    vector<Customer*> customers;
    vector<DeliveryDriver*> drivers;
    vector<FoodItem*> items;
    vector<Order*> orders;

    Customer* cust = nullptr;
    FoodItem* foodI = nullptr;
    Order* ord = nullptr;
    DeliveryDriver* DD = nullptr;

    do {
        cout << "===== ELMENUS MANAGEMENT SYSTEM V1.0 =====\n\n"
            << "====    USER MANAGEMNT   ====\n"
            << "---------------------------------\n"
            << "1.Register New Customer\n"
            << "2.Register New Delivery Driver\n"
            << "---------------------------------\n\n"
            << "=====  ORDER MANAGEMENT    ====\n"
            << "--------------------------------------------------\n"
            << "3.Create New Order \n"
            << "4.Add Items To Order \n"
            << "5.Assign Driver To Order \n"
            << "6.Update Order Status \n"
            << "7.Display Order Details \n"
            << "8.Display Customer Information \n"
            << "9.Display Driver Information \n"
            << "10.Compare Two Orders By Total \n"
            << "11.Display System Statistics \n"
            << "-------------------------------------------------- \n\n"
            << "=====   FILE OPERATIONS MANAGEMENT   ===== \n"
            << "--------------------------------------- \n"
            << "12.Save Completed Orders To File  \n"
            << "13.Save Driver Statistics To File \n"
            << "=====   BONUS FEATURES \n"
            << "14.[BONUS] Save Orders To Binary File \n"
            << "15.[BONUS] Load Order by Position(0..n) \n"
            << "16.[BONUS] Binary Files Statistics \n"
            << "--------------------------------------\n\n"
            << "17.Exit \n";

        cout << "Choose the number of operation you want\n";
        cin >> num;

        switch (num)
        {
        case 1:
        {
            cust = new Customer();
            customers.push_back(cust);
            cout << "New Customer created\n";
            break;
        }
        case 2:
        {
            DD = new DeliveryDriver();
            drivers.push_back(DD);
            cout << "New Driver created\n";
            break;
        }
        case 3:
        {
            ord = new Order();
            orders.push_back(ord);
            cout << "New Order created\n";
            break;
        }
        case 4:
        {
            foodI = new FoodItem();
            items.push_back(foodI);
            cout << "New Item created\n";
            
            break;
        }
        case 5:
        {
            if (!ord) {
                cout << "No order exists. Create an order first (option 3).\n";
            }
            else if (!DD) {
                cout << "No driver exists. Create a driver first (option 2).\n";
            }
            else {
                ord->assignDriver(DD);
                cout << "Driver is assigned\n";
            }
            break;
        }
        case 6:
        {
            if (!ord) {
                cout << "No order exists. Create an order first (option 3).\n";
                break;
            }
            cout << "--- Update Order Status ---\n";
            cout << "Enter the index of new status: 0=PENDING, 1=ASSIGNED, 2=DELIVERED \n";
            int idx;
            cin >> idx;
            if (idx < 0 || idx > 2)
            {
                cout << "Status is wrong. \n\n";
            }
            else if (idx == 0 || idx == 1)
            {
                cout << "Not Delivered until now.\n\n";
                ord->updateStatus(static_cast<OrderStatus>(idx));
            }
            else
            {
                ord->updateStatus(static_cast<OrderStatus>(idx));
                cout << "Order status updated to DELIVERED.\n";
            }
            break;
        }
        case 7:
        {
            if (!ord) {
                cout << "No order to display.\n";
            }
            else {
                ord->displayOrder();
            }
            break;
        }
        case 8:
        {
            if (!cust) {
                cout << "No customer to display.\n";
            }
            else {
                cust->displayInfo();
            }
            break;
        }
        case 9:
        {
            if (!DD) {
                cout << "No driver to display.\n";
            }
            else {
                DD->displayInfo();
            }
            break;
        }
        case 10:
        {
            if (orders.empty()) {
                cout << "No orders available to compare.\n";
                break;
            }
            {
                Order* ord2 = new Order();
                orders.push_back(ord2); 
                if (ord && ord2) {
                    if (ord > ord2)
                    {
                        cout << "Order " << ord->getOrderId() << " is larger.\n";
                    }
                    else if (ord2 > ord)
                    {
                        cout << "Order " << ord2->getOrderId() << " is larger.\n";
                    }
                    else {
                        cout << "Both orders have the same total.\n";
                    }
                }
                else {
                    cout << "Orders not available for comparison.\n";
                }
            }
            break;
        }
        case 11:
        {
            cout << "====== SYSTEM STATISTICS ======\n";

            cout << "Total Users: " << User::getTotalUsers() << "\n";
            cout << "Total Orders: " << Order::getTotalOrders() << "\n";

            cout << "Number of Customers: " << Customer::getCustomerCount() << "\n";
            cout << "Number of Drivers: " << DeliveryDriver::getDriversCount() << "\n";

            int deliveredCount = 0;
            for (auto o : orders) {
                if (o && o->getStatus() == OrderStatus::DELIVERED) ++deliveredCount;
            }
            cout << "Delivered Orders: " << deliveredCount << "\n";

            cout << "================================\n";
            break;
        }
        case 12:
        {
            saveCompletedOrders(orders, "CompletedOrders.txt");
            cout << "Saved to CompletedOrders.txt\n";
            break;
        }
        case 13:
        {
            saveDriverStats(drivers, "DriversStats.txt");
            cout << "Saved to DriversStats.txt\n";
            break;
        }
        case 14:
        {
            cout << "Orders saved to orders.dat\n";
            break;
        }
        case 15:
        {
            int pos;
            cout << "Enter order index to load (starting from 0): ";
            cin >> pos;
            loadOrderByPosition("orders.dat", pos);
            break;
        }
        case 16:
        {
            binaryFileStats("orders.dat");
            break;
        }
        case 17:
        {
            cout << "Exiting...\n";
            break;
        }
        default:
            cout << "Invalid choice\n";
            break;
        }

    } while (num != 17);

    // clean up
    for (auto p : customers) delete p;
    for (auto p : drivers) delete p;
    for (auto p : items) delete p;
    for (auto p : orders) delete p;

    return 0;
}