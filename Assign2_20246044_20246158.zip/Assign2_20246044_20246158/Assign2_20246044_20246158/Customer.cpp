
// GROUP 9
// Habiba  20246044 
// Maria   20246158

#include "Customer.h"
#include<iostream>
using namespace std;

  
// default constructor
Customer::Customer() :User() {
    deliveryAddress ="";
    loyaltyPoints = 0;
    cout<<"default customer crated"<<endl;
    customerCount++;
    
}

// parameterized constrctor
Customer::Customer(string id,string n,string num,string address,int point) :User (id,n,num){
    deliveryAddress =address;
    loyaltyPoints =point;
    customerCount++;

}

// display function
void Customer :: displayInfo() 
{
cout<<"Address "<< deliveryAddress<< endl;
   cout<<"Loyalty points "<<loyaltyPoints <<endl;
    }

    // calculateEarnings function
    double Customer :: calculateEarnings()
    {
        return loyaltyPoints* 0.5;
    
    }

    // Setters
    void Customer :: setdeliveryAddress(string address)
    {
        deliveryAddress =address;
    
    }
    void Customer :: setloyaltyPoints(int point){
    loyaltyPoints =point;
    }

    // Getters
        string Customer :: getdeliveryAddress() const{
        return deliveryAddress; 
    }
    int Customer :: getloyaltyPoints() const{
        return loyaltyPoints;
    }

    int Customer::getCustomerCount()
    {
        return customerCount;
    }

    
    // Operator+=
    Customer& Customer::operator+=(int points){
        loyaltyPoints += points;
        return *this;
    }

    Customer::~Customer()
    {
        customerCount--;
    }
