
// GROUP 9
// Habiba  20246044 
// Maria   20246158

#pragma once
#include "User.h"
#include<iostream>
using namespace std;
class DeliveryDriver : public User
{
    private :
    string VehicleType;
    int completedDeliveries;
    double totalEarnings;
    static int DriversCount;

    public :
     //Constructors

    DeliveryDriver ();
    DeliveryDriver (string id,string n,string num,string type,int deliver,double total) ;

    // override functions
    void displayInfo();
    double calculateEarnings();

    //Methods
    void completeDelivery(double orderValue);

    // Operator overloading
     DeliveryDriver& operator++();
     DeliveryDriver operator++(int);

     //Getters
     string getVehicleType() const;
     int getcompletedDeliveries() const;
     double gettotalEarnings() const;
     static int getDriversCount();
     
     // Destructor
     ~DeliveryDriver();

};